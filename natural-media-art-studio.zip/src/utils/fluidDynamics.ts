/**
 * Fluid Dynamics & Media Interaction Engine
 * 
 * This module simulates watercolor pigment suspension, water flow (using a simplified 
 * grid-based Navier-Stokes and cellular flow approximation), paper absorption, 
 * and pigment deposition into paper grain.
 * 
 * It also handles oil impasto height-map physics (thick paint accumulation, 
 * smear blending, and normal-map generation for 3D lighting).
 */

import { PaperSettings } from '../types';

export class FluidSimulator {
  public width: number;
  public height: number;
  public scale: number; // Scale factor from canvas coordinates to simulation grid

  // Watercolor arrays (grid-based)
  public water: Float32Array;      // Water density
  public u: Float32Array;          // Horizontal velocity
  public v: Float32Array;          // Vertical velocity
  public pigmentR: Float32Array;   // Suspended Red pigment
  public pigmentG: Float32Array;   // Suspended Green pigment
  public pigmentB: Float32Array;   // Suspended Blue pigment
  
  // Dry pigment deposited on paper fibers (fixed/rendered)
  public dryR: Uint8ClampedArray;
  public dryG: Uint8ClampedArray;
  public dryB: Uint8ClampedArray;
  public dryAlpha: Uint8ClampedArray;

  // Paper grain cache
  public grainHeight: Float32Array;

  constructor(width: number, height: number, scale: number = 4) {
    this.width = Math.ceil(width / scale);
    this.height = Math.ceil(height / scale);
    this.scale = scale;

    const size = this.width * this.height;
    this.water = new Float32Array(size);
    this.u = new Float32Array(size);
    this.v = new Float32Array(size);
    this.pigmentR = new Float32Array(size);
    this.pigmentG = new Float32Array(size);
    this.pigmentB = new Float32Array(size);

    this.dryR = new Uint8ClampedArray(size);
    this.dryG = new Uint8ClampedArray(size);
    this.dryB = new Uint8ClampedArray(size);
    this.dryAlpha = new Uint8ClampedArray(size);

    this.grainHeight = new Float32Array(size);
  }

  /**
   * Generates paper grain heightmap based on paper settings.
   */
  public generatePaperGrain(settings: PaperSettings) {
    const size = this.width * this.height;
    const roughness = settings.roughness;
    const scale = settings.fiberScale * 10 + 2;

    for (let y = 0; y < this.height; y++) {
      for (let x = 0; x < this.width; x++) {
        const idx = y * this.width + x;
        
        // Combine a few octaves of noise for organic feel
        const n1 = Math.sin(x / scale) * Math.cos(y / scale);
        const n2 = Math.sin((x + y) / (scale * 0.5)) * 0.5;
        const n3 = Math.cos((x - y) / (scale * 2)) * 0.25;
        
        // Paper fiber noise
        let fiber = (n1 + n2 + n3 + 1.75) / 3.5; // 0..1
        
        // Canvas pattern overlay if linene
        if (settings.type === 'canvas_linen') {
          const gridX = Math.abs(Math.sin(x / 1.5));
          const gridY = Math.abs(Math.cos(y / 1.5));
          fiber = (fiber * 0.4) + (gridX * gridY * 0.6);
        }

        this.grainHeight[idx] = fiber * roughness;
      }
    }
  }

  /**
   * Deposit water and pigment at a location.
   */
  public injectPaint(
    canvasX: number,
    canvasY: number,
    radius: number,
    r: number,
    g: number,
    b: number,
    amount: number, // water / fluid load
    pigmentLoad: number // pigment load
  ) {
    const simX = Math.floor(canvasX / this.scale);
    const simY = Math.floor(canvasY / this.scale);
    const simR = Math.ceil(radius / this.scale);

    for (let dy = -simR; dy <= simR; dy++) {
      const y = simY + dy;
      if (y < 0 || y >= this.height) continue;

      for (let dx = -simR; dx <= simR; dx++) {
        const x = simX + dx;
        if (x < 0 || x >= this.width) continue;

        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > simR) continue;

        const falloff = 1 - (dist / simR);
        const idx = y * this.width + x;

        // Add water density
        this.water[idx] = Math.min(5.0, this.water[idx] + amount * falloff * 2);

        // Add suspended pigments (blend with existing suspended pigments)
        const totalPigment = pigmentLoad * falloff * 5;
        this.pigmentR[idx] = (this.pigmentR[idx] * 0.3) + (r * totalPigment * 0.7);
        this.pigmentG[idx] = (this.pigmentG[idx] * 0.3) + (g * totalPigment * 0.7);
        this.pigmentB[idx] = (this.pigmentB[idx] * 0.3) + (b * totalPigment * 0.7);

        // Add minor initial outward velocity
        if (dist > 0) {
          this.u[idx] += (dx / dist) * amount * falloff * 0.5;
          this.v[idx] += (dy / dist) * amount * falloff * 0.5;
        }
      }
    }
  }

  /**
   * Physical update step: fluids flow, bleed, dry, and deposit pigments.
   */
  public step(paper: PaperSettings) {
    const size = this.width * this.height;
    const nextWater = new Float32Array(size);
    const nextPigmentR = new Float32Array(size);
    const nextPigmentG = new Float32Array(size);
    const nextPigmentB = new Float32Array(size);

    const absorptionRate = 0.005 * (1 + paper.absorption * 2);
    const grainInfluence = paper.grainDepth;

    for (let y = 1; y < this.height - 1; y++) {
      for (let x = 1; x < this.width - 1; x++) {
        const idx = y * this.width + x;
        const w = this.water[idx];

        if (w <= 0.01) {
          // Dry pixel: any remaining suspended pigment is fully deposited
          if (this.pigmentR[idx] > 0 || this.pigmentG[idx] > 0 || this.pigmentB[idx] > 0) {
            const pr = Math.min(255, this.pigmentR[idx]);
            const pg = Math.min(255, this.pigmentG[idx]);
            const pb = Math.min(255, this.pigmentB[idx]);
            const alpha = Math.min(255, (pr + pg + pb) / 3 * 2);

            // Layer-additive dry pigment
            this.dryR[idx] = Math.max(this.dryR[idx], pr);
            this.dryG[idx] = Math.max(this.dryG[idx], pg);
            this.dryB[idx] = Math.max(this.dryB[idx], pb);
            this.dryAlpha[idx] = Math.min(255, this.dryAlpha[idx] + alpha);

            this.pigmentR[idx] = 0;
            this.pigmentG[idx] = 0;
            this.pigmentB[idx] = 0;
          }
          continue;
        }

        // Neighbors
        const idxN = (y - 1) * this.width + x;
        const idxS = (y + 1) * this.width + x;
        const idxW = y * this.width + (x - 1);
        const idxE = y * this.width + (x + 1);

        // 1. GRAVITY / SLOPE FLOW: Water flows down grain height slopes
        const hC = this.grainHeight[idx];
        const hN = this.grainHeight[idxN];
        const hS = this.grainHeight[idxS];
        const hW = this.grainHeight[idxW];
        const hE = this.grainHeight[idxE];

        // Slopes
        const slopeX = (hW - hE) * grainInfluence * 0.1;
        const slopeY = (hN - hS) * grainInfluence * 0.1;

        // Apply slope to velocity
        this.u[idx] += slopeX;
        this.v[idx] += slopeY;

        // Dampen velocity (friction/viscosity)
        this.u[idx] *= 0.85;
        this.v[idx] *= 0.85;

        // 2. FLOW ADVECTION: Calculate how water & pigment distribute
        // Simple advective cellular sharing based on velocity and diffusion
        const velX = this.u[idx];
        const velY = this.v[idx];

        // Distribute to neighbors
        const flowE = Math.max(0, velX) * 0.15 + 0.1 * w;
        const flowW = Math.max(0, -velX) * 0.15 + 0.1 * w;
        const flowS = Math.max(0, velY) * 0.15 + 0.1 * w;
        const flowN = Math.max(0, -velY) * 0.15 + 0.1 * w;

        const totalOutflow = flowE + flowW + flowS + flowN;
        const remainingWater = Math.max(0, w - totalOutflow);

        // Add to neighbors (accumulation step)
        nextWater[idx] += remainingWater;
        nextWater[idxE] += flowE;
        nextWater[idxW] += flowW;
        nextWater[idxS] += flowS;
        nextWater[idxN] += flowN;

        // Pigment travels with water
        const pigRatio = w > 0 ? totalOutflow / w : 0;
        const outPigR = this.pigmentR[idx] * pigRatio;
        const outPigG = this.pigmentG[idx] * pigRatio;
        const outPigB = this.pigmentB[idx] * pigRatio;

        const remPigR = this.pigmentR[idx] - outPigR;
        const remPigG = this.pigmentG[idx] - outPigG;
        const remPigB = this.pigmentB[idx] - outPigB;

        nextPigmentR[idx] += remPigR;
        nextPigmentG[idx] += remPigG;
        nextPigmentB[idx] += remPigB;

        if (totalOutflow > 0) {
          nextPigmentR[idxE] += outPigR * (flowE / totalOutflow);
          nextPigmentR[idxW] += outPigR * (flowW / totalOutflow);
          nextPigmentR[idxS] += outPigR * (flowS / totalOutflow);
          nextPigmentR[idxN] += outPigR * (flowN / totalOutflow);

          nextPigmentG[idxE] += outPigG * (flowE / totalOutflow);
          nextPigmentG[idxW] += outPigG * (flowW / totalOutflow);
          nextPigmentG[idxS] += outPigG * (flowS / totalOutflow);
          nextPigmentG[idxN] += outPigG * (flowN / totalOutflow);

          nextPigmentB[idxE] += outPigB * (flowE / totalOutflow);
          nextPigmentB[idxW] += outPigB * (flowW / totalOutflow);
          nextPigmentB[idxS] += outPigB * (flowS / totalOutflow);
          nextPigmentB[idxN] += outPigB * (flowN / totalOutflow);
        }

        // 3. EVAPORATION / ABSORPTION
        nextWater[idx] = Math.max(0, nextWater[idx] - absorptionRate);

        // 4. GRANULAR SETTLING: Trapped pigments settle into valleys
        // If water level gets shallow, pigments attach to high grain elevations first
        if (nextWater[idx] < 0.2) {
          const settleRate = (0.2 - nextWater[idx]) * 2.0;
          const trappedRatio = settleRate * (1.0 - this.grainHeight[idx]); // valleys retain pigment more!
          
          const sR = nextPigmentR[idx] * trappedRatio;
          const sG = nextPigmentG[idx] * trappedRatio;
          const sB = nextPigmentB[idx] * trappedRatio;

          this.dryR[idx] = Math.min(255, this.dryR[idx] + sR);
          this.dryG[idx] = Math.min(255, this.dryG[idx] + sG);
          this.dryB[idx] = Math.min(255, this.dryB[idx] + sB);
          this.dryAlpha[idx] = Math.min(255, this.dryAlpha[idx] + trappedRatio * 255);

          nextPigmentR[idx] -= sR;
          nextPigmentG[idx] -= sG;
          nextPigmentB[idx] -= sB;
        }
      }
    }

    // Apply updates
    this.water.set(nextWater);
    this.pigmentR.set(nextPigmentR);
    this.pigmentG.set(nextPigmentG);
    this.pigmentB.set(nextPigmentB);
  }

  /**
   * Draw the fluid simulation state onto an output ImageData or Canvas Context.
   */
  public drawToContext(ctx: CanvasRenderingContext2D) {
    const imgData = ctx.createImageData(ctx.canvas.width, ctx.canvas.height);
    const data = imgData.data;

    const paperColorR = 255; // White paper base
    const paperColorG = 255;
    const paperColorB = 255;

    // Up-sample the grid back to canvas resolution
    for (let cy = 0; cy < ctx.canvas.height; cy++) {
      const sy = Math.floor(cy / this.scale);
      const simY = Math.min(this.height - 1, sy);

      for (let cx = 0; cx < ctx.canvas.width; cx++) {
        const sx = Math.floor(cx / this.scale);
        const simX = Math.min(this.width - 1, sx);

        const sIdx = simY * this.width + simX;
        const cIdx = (cy * ctx.canvas.width + cx) * 4;

        // Mix dry pigment and active suspended pigment
        const dryRVal = this.dryR[sIdx];
        const dryGVal = this.dryG[sIdx];
        const dryBVal = this.dryB[sIdx];
        const dryAVal = this.dryAlpha[sIdx] / 255;

        const wetRVal = this.pigmentR[sIdx];
        const wetGVal = this.pigmentG[sIdx];
        const wetBVal = this.pigmentB[sIdx];
        const wetLoad = Math.min(1.0, this.water[sIdx]);

        // Blended pixel pigment
        let finalR = dryRVal * dryAVal + wetRVal * wetLoad * (1 - dryAVal);
        let finalG = dryGVal * dryAVal + wetGVal * wetLoad * (1 - dryAVal);
        let finalB = dryBVal * dryAVal + wetBVal * wetLoad * (1 - dryAVal);
        let finalA = Math.max(dryAVal, wetLoad);

        if (finalA > 0.02) {
          // Multiply/blend with background paper color
          data[cIdx] = Math.round(finalR);
          data[cIdx + 1] = Math.round(finalG);
          data[cIdx + 2] = Math.round(finalB);
          data[cIdx + 3] = Math.round(finalA * 255);
        } else {
          data[cIdx] = paperColorR;
          data[cIdx + 1] = paperColorG;
          data[cIdx + 2] = paperColorB;
          data[cIdx + 3] = 0; // transparent layer
        }
      }
    }

    ctx.putImageData(imgData, 0, 0);
  }

  /**
   * Reset/clear the fluid grid.
   */
  public clear() {
    this.water.fill(0);
    this.u.fill(0);
    this.v.fill(0);
    this.pigmentR.fill(0);
    this.pigmentG.fill(0);
    this.pigmentB.fill(0);
    this.dryR.fill(0);
    this.dryG.fill(0);
    this.dryB.fill(0);
    this.dryAlpha.fill(0);
  }
}

/**
 * 3D Impasto Engine for Oil paint simulation.
 * Manages thickness heightmaps and light reflection rendering.
 */
export class ImpastoEngine {
  public width: number;
  public height: number;
  public heightMap: Float32Array; // Paint height/thickness at each pixel
  public normalMap: Float32Array; // Cached normals (dx, dy, dz)

  constructor(width: number, height: number) {
    this.width = width;
    this.height = height;
    this.heightMap = new Float32Array(width * height);
    this.normalMap = new Float32Array(width * height * 3);
    this.resetNormals();
  }

  private resetNormals() {
    for (let i = 0; i < this.width * this.height; i++) {
      const idx = i * 3;
      this.normalMap[idx] = 0.0;     // Nx
      this.normalMap[idx + 1] = 0.0; // Ny
      this.normalMap[idx + 2] = 1.0; // Nz
    }
  }

  /**
   * Apply oil paint volume and blend with neighboring heights.
   */
  public depositOil(
    x: number,
    y: number,
    radius: number,
    thickness: number
  ) {
    const rx = Math.round(x);
    const ry = Math.round(y);
    const r = Math.ceil(radius);

    for (let dy = -r; dy <= r; dy++) {
      const py = ry + dy;
      if (py < 0 || py >= this.height) continue;

      for (let dx = -r; dx <= r; dx++) {
        const px = rx + dx;
        if (px < 0 || px >= this.width) continue;

        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist > r) continue;

        const idx = py * this.width + px;
        const falloff = 1.0 - (dist / r);
        
        // Add thickness
        this.heightMap[idx] = Math.min(10.0, this.heightMap[idx] + thickness * falloff * 0.8);
      }
    }
    
    // Recompute normals around updated region
    this.computeNormalsSubset(rx - r - 2, ry - r - 2, rx + r + 2, ry + r + 2);
  }

  /**
   * Recompute normal map vectors based on height gradients.
   */
  private computeNormalsSubset(xStart: number, yStart: number, xEnd: number, yEnd: number) {
    const x0 = Math.max(1, xStart);
    const y0 = Math.max(1, yStart);
    const x1 = Math.min(this.width - 2, xEnd);
    const y1 = Math.min(this.height - 2, yEnd);

    // Sobel filters for height gradients
    for (let y = y0; y <= y1; y++) {
      for (let x = x0; x <= x1; x++) {
        const idx = y * this.width + x;

        // Heights of neighbors
        const hNW = this.heightMap[(y - 1) * this.width + (x - 1)];
        const hN  = this.heightMap[(y - 1) * this.width + x];
        const hNE = this.heightMap[(y - 1) * this.width + (x + 1)];
        const hW  = this.heightMap[y * this.width + (x - 1)];
        const hE  = this.heightMap[y * this.width + (x + 1)];
        const hSW = this.heightMap[(y + 1) * this.width + (x - 1)];
        const hS  = this.heightMap[(y + 1) * this.width + x];
        const hSE = this.heightMap[(y + 1) * this.width + (x + 1)];

        // Compute gradients (Sobel filter)
        // We multiply gradient by scale factor to adjust visual depth
        const depthScale = 1.8;
        const dx = -((hNE + 2 * hE + hSE) - (hNW + 2 * hW + hSW)) * depthScale;
        const dy = -((hSW + 2 * hS + hSE) - (hNW + 2 * hN + hNE)) * depthScale;
        const dz = 1.0;

        // Normalize
        const len = Math.sqrt(dx * dx + dy * dy + dz * dz);
        const normalIdx = idx * 3;
        this.normalMap[normalIdx] = dx / len;
        this.normalMap[normalIdx + 1] = dy / len;
        this.normalMap[normalIdx + 2] = dz / len;
      }
    }
  }

  /**
   * Renders the 3D-lit shaded paint.
   * Uses phong specular lighting with adjustable light position.
   */
  public renderShaded(
    sourceCtx: CanvasRenderingContext2D,
    destCtx: CanvasRenderingContext2D,
    lightAngleDeg: number = 135,
    lightHeight: number = 0.5 // 0.1 to 1.0
  ) {
    const imgData = sourceCtx.getImageData(0, 0, this.width, this.height);
    const sData = imgData.data;
    
    const outputImgData = destCtx.createImageData(this.width, this.height);
    const dData = outputImgData.data;

    // Light direction vector
    const rad = (lightAngleDeg * Math.PI) / 180;
    const Lx = Math.cos(rad);
    const Ly = Math.sin(rad);
    const Lz = lightHeight;
    const LLen = Math.sqrt(Lx * Lx + Ly * Ly + Lz * Lz);
    const lXNorm = Lx / LLen;
    const lYNorm = Ly / LLen;
    const lZNorm = Lz / LLen;

    const ambient = 0.65;
    const specularStrength = 0.45;
    const shininess = 16.0;

    for (let i = 0; i < this.width * this.height; i++) {
      const cIdx = i * 4;
      const nIdx = i * 3;

      const alpha = sData[cIdx + 3] / 255;
      if (alpha <= 0.01) {
        // Transparent
        dData[cIdx] = 0;
        dData[cIdx + 1] = 0;
        dData[cIdx + 2] = 0;
        dData[cIdx + 3] = 0;
        continue;
      }

      // Normal vector
      const nx = this.normalMap[nIdx];
      const ny = this.normalMap[nIdx + 1];
      const nz = this.normalMap[nIdx + 2];

      // Lambertian diffuse: N dot L
      const nDotL = Math.max(0.0, nx * lXNorm + ny * lYNorm + nz * lZNorm);

      // Specular highlight (reflective shine)
      // Halfway vector (assuming view vector is [0, 0, 1])
      const hx = lXNorm;
      const hy = lYNorm;
      const hz = lZNorm + 1.0;
      const hLen = Math.sqrt(hx * hx + hy * hy + hz * hz);
      const hxNorm = hx / hLen;
      const hyNorm = hy / hLen;
      const hzNorm = hz / hLen;

      const nDotH = Math.max(0.0, nx * hxNorm + ny * hyNorm + nz * hzNorm);
      const specular = Math.pow(nDotH, shininess) * specularStrength;

      // Color calculations
      const r = sData[cIdx];
      const g = sData[cIdx + 1];
      const b = sData[cIdx + 2];

      // Blended shaded color
      const intensity = ambient + (1.0 - ambient) * nDotL;
      
      dData[cIdx] = Math.min(255, Math.round(r * intensity + specular * 255));
      dData[cIdx + 1] = Math.min(255, Math.round(g * intensity + specular * 255));
      dData[cIdx + 2] = Math.min(255, Math.round(b * intensity + specular * 255));
      dData[cIdx + 3] = sData[cIdx + 3];
    }

    destCtx.putImageData(outputImgData, 0, 0);
  }

  public clear() {
    this.heightMap.fill(0);
    this.resetNormals();
  }
}
