import React, { useRef, useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  ArrowLeft, Save, Trash2, Eye, EyeOff, Layers, Download, Sliders, Play, Pause, ChevronRight
} from 'lucide-react';
import { Artwork, BrushSettings, Layer, PaperSettings } from '../types';
import { BrushEngine } from '../utils/brushEngine';
import { FluidSimulator, ImpastoEngine } from '../utils/fluidDynamics';
import RadialMenu from './RadialMenu';

interface DrawingCanvasProps {
  artwork: Artwork;
  onBack: () => void;
  onSave: (artwork: Artwork, previewUrl: string) => void;
}

export default function DrawingCanvas({
  artwork,
  onBack,
  onSave,
}: DrawingCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Canvas Elements
  const displayCanvasRef = useRef<HTMLCanvasElement>(null);
  const paperCanvasRef = useRef<HTMLCanvasElement>(null);
  const compositeCanvasRef = useRef<HTMLCanvasElement>(null);

  // Drawing state
  const [activeLayerId, setActiveLayerId] = useState<string>(artwork.activeLayerId);
  const [layers, setLayers] = useState<Layer[]>(artwork.layers);
  const [paper, setPaper] = useState<PaperSettings>(artwork.paperSettings);
  const [isPainting, setIsPainting] = useState<boolean>(false);

  // Brush settings
  const [brushSettings, setBrushSettings] = useState<BrushSettings>({
    type: 'watercolor',
    size: 25,
    opacity: 0.8,
    fluidity: 0.75,
    paintLoad: 0.8,
    grainInfluence: 0.5,
    pressureSensitivity: 0.7,
    tiltInfluence: 0.5,
    color: '#e32636', // Cadmium Red default
  });

  // Engines
  const brushEngineRef = useRef<BrushEngine>(new BrushEngine());
  const fluidSimsRef = useRef<Record<string, FluidSimulator>>({});
  const impastoEnginesRef = useRef<Record<string, ImpastoEngine>>({});
  const layerCanvasesRef = useRef<Record<string, HTMLCanvasElement>>({});

  // Simulation controls
  const [fluidSimRunning, setFluidSimRunning] = useState<boolean>(true);
  const [lightAngle, setLightAngle] = useState<number>(135);
  const [lightHeight, setLightHeight] = useState<number>(0.5);

  // Radial Menu State
  const [radialMenu, setRadialMenu] = useState<{
    isOpen: boolean;
    x: number;
    y: number;
  }>({ isOpen: false, x: 0, y: 0 });

  const spacePressedRef = useRef<boolean>(false);

  // Set up canvases and engines on mount or resize
  useEffect(() => {
    const width = artwork.width;
    const height = artwork.height;

    // Set sizes
    if (displayCanvasRef.current) {
      displayCanvasRef.current.width = width;
      displayCanvasRef.current.height = height;
    }
    if (paperCanvasRef.current) {
      paperCanvasRef.current.width = width;
      paperCanvasRef.current.height = height;
    }
    if (compositeCanvasRef.current) {
      compositeCanvasRef.current.width = width;
      compositeCanvasRef.current.height = height;
    }

    // Initialize/sync canvas for each layer
    layers.forEach((layer) => {
      if (!layerCanvasesRef.current[layer.id]) {
        const canv = document.createElement('canvas');
        canv.width = width;
        canv.height = height;
        layerCanvasesRef.current[layer.id] = canv;

        // Clear canvas with transparency
        const ctx = canv.getContext('2d');
        if (ctx) {
          ctx.clearRect(0, 0, width, height);
        }
      }

      // Initialize fluid/impasto engines
      if (!fluidSimsRef.current[layer.id]) {
        fluidSimsRef.current[layer.id] = new FluidSimulator(width, height, 4);
        fluidSimsRef.current[layer.id].generatePaperGrain(paper);
      }
      if (!impastoEnginesRef.current[layer.id]) {
        impastoEnginesRef.current[layer.id] = new ImpastoEngine(width, height);
      }
    });

    renderPaperBackground();
    compositeCanvas();

    // Resize container layout to fit inside workspace cleanly
    const handleResize = () => {
      // Fluid resize of viewer container is handled by CSS flex/aspect ratios
    };

    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, [artwork, layers.length]);

  // Handle Paper Settings changes
  useEffect(() => {
    // Regenerate grain for all fluid simulators
    (Object.values(fluidSimsRef.current) as FluidSimulator[]).forEach((sim) => {
      sim.generatePaperGrain(paper);
    });
    renderPaperBackground();
    compositeCanvas();
  }, [paper]);

  // Spacebar Event Listeners for summoning Radial Menu
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        spacePressedRef.current = true;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.code === 'Space') {
        e.preventDefault();
        spacePressedRef.current = false;
        // Keep radial menu open if clicked, but let releasing spacebar close it optionally
        if (radialMenu.isOpen) {
          setRadialMenu((prev) => ({ ...prev, isOpen: false }));
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [radialMenu.isOpen]);

  // Simulation Update Ticker
  useEffect(() => {
    let animationFrameId: number;

    const tick = () => {
      if (fluidSimRunning) {
        let updated = false;

        layers.forEach((layer) => {
          const sim = fluidSimsRef.current[layer.id];
          if (sim && layer.visible) {
            // Check if there's active water/fluid to simulate
            let activeFluid = false;
            for (let i = 0; i < sim.water.length; i += 100) { // sparse check for performance
              if (sim.water[i] > 0.01) {
                activeFluid = true;
                break;
              }
            }

            if (activeFluid) {
              sim.step(paper);
              const layerCanvas = layerCanvasesRef.current[layer.id];
              const layerCtx = layerCanvas?.getContext('2d');
              if (layerCtx) {
                layerCtx.clearRect(0, 0, artwork.width, artwork.height);
                sim.drawToContext(layerCtx);
              }
              updated = true;
            }
          }
        });

        if (updated) {
          compositeCanvas();
        }
      }
      animationFrameId = requestAnimationFrame(tick);
    };

    animationFrameId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(animationFrameId);
  }, [layers, paper, fluidSimRunning]);

  /**
   * Renders the tactile paper background, with grain shadowing relief.
   */
  const renderPaperBackground = () => {
    const canvas = paperCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;

    // Fill base color
    ctx.fillStyle = paper.color || '#faf8f5';
    ctx.fillRect(0, 0, w, h);

    // Apply relief shading using paper grain map
    const sim = fluidSimsRef.current[activeLayerId];
    if (sim) {
      const imgData = ctx.getImageData(0, 0, w, h);
      const data = imgData.data;

      const lightAngleRad = (lightAngle * Math.PI) / 180;
      const lx = Math.cos(lightAngleRad);
      const ly = Math.sin(lightAngleRad);
      const lz = lightHeight * 0.5;

      const scale = sim.scale;
      const grainDepth = paper.grainDepth * 25;

      for (let cy = 1; cy < h - 1; cy++) {
        const sy = Math.floor(cy / scale);
        const simY = Math.min(sim.height - 1, sy);

        for (let cx = 1; cx < w - 1; cx++) {
          const sx = Math.floor(cx / scale);
          const simX = Math.min(sim.width - 1, sx);

          const idx = (cy * w + cx) * 4;

          // Compute slope from grain heights
          const hC = sim.grainHeight[simY * sim.width + simX];
          const hW = sim.grainHeight[simY * sim.width + Math.max(0, simX - 1)];
          const hE = sim.grainHeight[simY * sim.width + Math.min(sim.width - 1, simX + 1)];
          const hN = sim.grainHeight[Math.max(0, simY - 1) * sim.width + simX];
          const hS = sim.grainHeight[Math.min(sim.height - 1, simY + 1) * sim.width + simX];

          const dx = hW - hE;
          const dy = hN - hS;

          // Dot product with light
          const dot = (dx * lx + dy * ly + lz) / Math.sqrt(dx * dx + dy * dy + lz * lz);
          const shadowFactor = (dot - 0.5) * grainDepth;

          data[idx] = Math.max(0, Math.min(255, data[idx] + shadowFactor));
          data[idx + 1] = Math.max(0, Math.min(255, data[idx + 1] + shadowFactor));
          data[idx + 2] = Math.max(0, Math.min(255, data[idx + 2] + shadowFactor));
        }
      }
      ctx.putImageData(imgData, 0, 0);
    }
  };

  /**
   * Composites paper and visible drawing layers onto display/interactive canvas.
   */
  const compositeCanvas = () => {
    const canvas = compositeCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // 1. Draw Paper background
    if (paperCanvasRef.current) {
      ctx.drawImage(paperCanvasRef.current, 0, 0);
    }

    // 2. Overlay each active/visible drawing layer
    layers.forEach((layer) => {
      if (!layer.visible) return;

      const layerCanvas = layerCanvasesRef.current[layer.id];
      const impasto = impastoEnginesRef.current[layer.id];

      if (layerCanvas) {
        ctx.save();
        ctx.globalAlpha = layer.opacity;

        // Apply blend modes
        if (layer.blendMode === 'multiply') ctx.globalCompositeOperation = 'multiply';
        else if (layer.blendMode === 'screen') ctx.globalCompositeOperation = 'screen';
        else if (layer.blendMode === 'overlay') ctx.globalCompositeOperation = 'overlay';
        else ctx.globalCompositeOperation = 'source-over';

        // Oil layer requires real-time 3D impasto light shading
        const wetOilCheck = brushSettings.type === 'oil' && layer.id === activeLayerId;
        const containsHeights = impasto && impasto.heightMap.some(h => h > 0.05);

        if (containsHeights) {
          // Setup offscreen canvas to render shaded paint
          const shadedCanvas = document.createElement('canvas');
          shadedCanvas.width = canvas.width;
          shadedCanvas.height = canvas.height;
          const shadedCtx = shadedCanvas.getContext('2d');
          
          if (shadedCtx) {
            const layerCtx = layerCanvas.getContext('2d');
            if (layerCtx) {
              impasto.renderShaded(layerCtx, shadedCtx, lightAngle, lightHeight);
              ctx.drawImage(shadedCanvas, 0, 0);
            }
          }
        } else {
          // Standard alpha rendering
          ctx.drawImage(layerCanvas, 0, 0);
        }

        ctx.restore();
      }
    });

    // 3. Render complete composited picture to active Display Canvas
    const dCtx = displayCanvasRef.current?.getContext('2d');
    if (dCtx && displayCanvasRef.current) {
      dCtx.clearRect(0, 0, displayCanvasRef.current.width, displayCanvasRef.current.height);
      dCtx.drawImage(canvas, 0, 0);
    }
  };

  /**
   * High-precision Pointer Event Listeners (stylus pressure/tilt).
   */
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = displayCanvasRef.current;
    if (!canvas) return;

    // Check if user is holding Spacebar AND clicking to summon Radial Menu
    if (spacePressedRef.current || e.button === 1 || radialMenu.isOpen) {
      e.preventDefault();
      const rect = canvas.getBoundingClientRect();
      const clickX = e.clientX - rect.left;
      const clickY = e.clientY - rect.top;

      setRadialMenu({
        isOpen: true,
        x: clickX,
        y: clickY,
      });
      return;
    }

    // Standard draw
    canvas.setPointerCapture(e.pointerId);
    setIsPainting(true);

    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvas.height;

    const pressure = e.pointerType === 'pen' ? e.pressure : 0.5;
    const tiltX = e.tiltX || 0;
    const tiltY = e.tiltY || 0;

    const activeCanvas = layerCanvasesRef.current[activeLayerId];
    const activeCtx = activeCanvas?.getContext('2d');
    const sim = fluidSimsRef.current[activeLayerId];
    const impasto = impastoEnginesRef.current[activeLayerId];

    if (activeCtx && sim && impasto) {
      brushEngineRef.current.resetStroke();
      brushEngineRef.current.drawStrokeSegment(
        activeCtx,
        x,
        y,
        pressure,
        tiltX,
        tiltY,
        brushSettings,
        paper,
        sim,
        impasto,
        canvas.width,
        canvas.height
      );
      compositeCanvas();
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isPainting || radialMenu.isOpen) return;

    const canvas = displayCanvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * canvas.width;
    const y = ((e.clientY - rect.top) / rect.height) * canvas.height;

    const pressure = e.pointerType === 'pen' ? e.pressure : 0.5;
    const tiltX = e.tiltX || 0;
    const tiltY = e.tiltY || 0;

    const activeCanvas = layerCanvasesRef.current[activeLayerId];
    const activeCtx = activeCanvas?.getContext('2d');
    const sim = fluidSimsRef.current[activeLayerId];
    const impasto = impastoEnginesRef.current[activeLayerId];

    if (activeCtx && sim && impasto) {
      brushEngineRef.current.drawStrokeSegment(
        activeCtx,
        x,
        y,
        pressure,
        tiltX,
        tiltY,
        brushSettings,
        paper,
        sim,
        impasto,
        canvas.width,
        canvas.height
      );
      compositeCanvas();
    }
  };

  const handlePointerUp = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (isPainting) {
      const canvas = displayCanvasRef.current;
      if (canvas) {
        canvas.releasePointerCapture(e.pointerId);
      }
      setIsPainting(false);
      brushEngineRef.current.resetStroke();
      compositeCanvas();
    }
  };

  // Layer Actions
  const handleAddLayer = () => {
    const newId = `layer-${Date.now()}`;
    const newLayer: Layer = {
      id: newId,
      name: `Layer ${layers.length + 1}`,
      visible: true,
      opacity: 1.0,
      blendMode: 'normal',
    };

    setLayers((prev) => [...prev, newLayer]);
    setActiveLayerId(newId);
  };

  const handleDeleteLayer = (id: string) => {
    if (layers.length <= 1) return;

    // Remove from engines
    delete layerCanvasesRef.current[id];
    delete fluidSimsRef.current[id];
    delete impastoEnginesRef.current[id];

    const updated = layers.filter((l) => l.id !== id);
    setLayers(updated);

    if (activeLayerId === id) {
      setActiveLayerId(updated[updated.length - 1].id);
    }
  };

  const handleToggleLayerVisibility = (id: string) => {
    setLayers((prev) =>
      prev.map((l) => (l.id === id ? { ...l, visible: !l.visible } : l))
    );
  };

  const handleLayerOpacityChange = (id: string, opacity: number) => {
    setLayers((prev) =>
      prev.map((l) => (l.id === id ? { ...l, opacity: opacity } : l))
    );
  };

  const handleClearCanvas = () => {
    if (confirm('Are you sure you want to clear the active layer? This cannot be undone.')) {
      const activeCanvas = layerCanvasesRef.current[activeLayerId];
      const activeCtx = activeCanvas?.getContext('2d');
      if (activeCtx) {
        activeCtx.clearRect(0, 0, artwork.width, artwork.height);
      }

      const sim = fluidSimsRef.current[activeLayerId];
      if (sim) {
        sim.clear();
      }

      const impasto = impastoEnginesRef.current[activeLayerId];
      if (impasto) {
        impasto.clear();
      }

      compositeCanvas();
    }
  };

  const handleExportPNG = () => {
    const canvas = compositeCanvasRef.current;
    if (!canvas) return;
    const url = canvas.toDataURL('image/png');
    const a = document.createElement('a');
    a.href = url;
    a.download = `${artwork.name || 'artwork'}.png`;
    a.click();
  };

  const handleSaveArtwork = () => {
    const canvas = compositeCanvasRef.current;
    if (!canvas) return;
    const previewUrl = canvas.toDataURL('image/jpeg', 0.85);

    // Save layer structures and settings back to drawing list
    const updatedArtwork: Artwork = {
      ...artwork,
      layers: layers,
      activeLayerId: activeLayerId,
      paperSettings: paper,
      updatedAt: Date.now(),
    };

    onSave(updatedArtwork, previewUrl);
  };

  return (
    <div className="flex flex-col h-screen w-screen bg-neutral-950 text-white overflow-hidden relative">
      {/* Header controls (Can be toggled or minimized for pure full-screen drawing) */}
      <header className="h-14 border-b border-neutral-800 bg-neutral-900/80 backdrop-blur px-6 flex items-center justify-between z-20">
        <div className="flex items-center gap-4">
          <button
            onClick={onBack}
            className="p-1.5 rounded-full hover:bg-neutral-800 text-neutral-300 hover:text-white transition-all cursor-pointer"
          >
            <ArrowLeft size={18} />
          </button>
          <div>
            <h1 className="text-sm font-semibold tracking-wide truncate max-w-[200px]">
              {artwork.name}
            </h1>
            <p className="text-[10px] text-neutral-500 uppercase font-mono">
              {artwork.width} x {artwork.height} px
            </p>
          </div>
        </div>

        {/* Dynamic Live indicators */}
        <div className="hidden md:flex items-center gap-4 text-xs font-mono bg-neutral-950/80 border border-neutral-800 px-3 py-1 rounded-full text-neutral-400">
          <span className="flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${fluidSimRunning ? 'bg-blue-500 animate-pulse' : 'bg-neutral-600'}`} />
            FLUID SOLVER: {fluidSimRunning ? 'ACTIVE' : 'PAUSED'}
          </span>
          <span className="text-neutral-600">|</span>
          <span>MEDIA: <b className="text-neutral-200 capitalize">{brushSettings.type}</b></span>
        </div>

        {/* Utilities */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setFluidSimRunning(!fluidSimRunning)}
            className="p-2 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700/50 rounded-lg text-neutral-300 hover:text-white cursor-pointer transition-all flex items-center gap-1 text-xs"
            title="Toggle Fluid Spread Animation"
          >
            {fluidSimRunning ? <Pause size={13} /> : <Play size={13} />}
            <span className="hidden sm:inline">Simulation</span>
          </button>

          <button
            onClick={handleExportPNG}
            className="p-2 bg-neutral-800 hover:bg-neutral-700 border border-neutral-700/50 rounded-lg text-neutral-300 hover:text-white cursor-pointer transition-all flex items-center gap-1 text-xs"
            title="Export to PNG"
          >
            <Download size={13} />
            <span className="hidden sm:inline">Export</span>
          </button>

          <button
            onClick={handleSaveArtwork}
            className="p-2 bg-neutral-100 hover:bg-white text-neutral-950 rounded-lg text-xs font-bold cursor-pointer transition-all flex items-center gap-1"
          >
            <Save size={13} />
            <span>Save</span>
          </button>
        </div>
      </header>

      {/* Main split viewport: Canvas center stage, sidebar (Paper and Impasto adjustments) */}
      <div className="flex-1 flex overflow-hidden relative">
        
        {/* Interactive Lighting / Paper Panel (Collapsible/Floating) */}
        <div className="absolute top-4 left-4 z-10 flex flex-col gap-2 bg-neutral-900/90 border border-neutral-800 p-3 rounded-xl backdrop-blur max-w-[240px] shadow-2xl text-[10px]">
          <div className="font-bold uppercase tracking-wide text-neutral-400 flex items-center justify-between border-b border-neutral-800 pb-1.5 mb-1.5">
            <span>Canvas Settings</span>
            <Sliders size={11} />
          </div>

          {/* Paper selector */}
          <div className="flex flex-col gap-1">
            <span className="text-neutral-500 font-mono">TEXTURE STYLE</span>
            <select
              value={paper.type}
              onChange={(e) => {
                const type = e.target.value as any;
                let roughness = 0.4;
                let absorption = 0.5;
                let fiberScale = 0.3;
                let grainDepth = 0.3;

                if (type === 'rough_watercolor') {
                  roughness = 0.8;
                  absorption = 0.8;
                  fiberScale = 0.55;
                  grainDepth = 0.65;
                } else if (type === 'smooth_hotpress') {
                  roughness = 0.15;
                  absorption = 0.45;
                  fiberScale = 0.2;
                  grainDepth = 0.15;
                } else if (type === 'canvas_linen') {
                  roughness = 0.65;
                  absorption = 0.25;
                  fiberScale = 0.7;
                  grainDepth = 0.75;
                } else if (type === 'smooth_layout') {
                  roughness = 0.05;
                  absorption = 0.1;
                  fiberScale = 0.1;
                  grainDepth = 0.05;
                }

                setPaper({
                  ...paper,
                  type,
                  roughness,
                  absorption,
                  fiberScale,
                  grainDepth,
                });
              }}
              className="bg-neutral-800 border border-neutral-700 rounded p-1 text-white font-sans text-[10px] cursor-pointer"
            >
              <option value="rough_watercolor">Rough Watercolor Paper</option>
              <option value="smooth_hotpress">Smooth Hotpress Paper</option>
              <option value="canvas_linen">Woven Linen Canvas</option>
              <option value="smooth_layout">Smooth Layout Board</option>
            </select>
          </div>

          {/* Dynamic Light Direction controls (for Impasto/Grain 3D effects) */}
          <div className="flex flex-col gap-1.5 mt-1 border-t border-neutral-800/50 pt-2">
            <div className="flex justify-between font-mono text-neutral-500">
              <span>LIGHT ANGLE</span>
              <span>{lightAngle}°</span>
            </div>
            <input
              type="range"
              min="0"
              max="360"
              value={lightAngle}
              onChange={(e) => {
                setLightAngle(parseInt(e.target.value));
                renderPaperBackground();
                compositeCanvas();
              }}
              className="w-full accent-white h-0.5 rounded-full cursor-pointer bg-neutral-700"
            />
          </div>

          <div className="flex flex-col gap-1.5">
            <div className="flex justify-between font-mono text-neutral-500">
              <span>LIGHT HEIGHT</span>
              <span>{Math.round(lightHeight * 100)}%</span>
            </div>
            <input
              type="range"
              min="0.1"
              max="1.0"
              step="0.05"
              value={lightHeight}
              onChange={(e) => {
                setLightHeight(parseFloat(e.target.value));
                renderPaperBackground();
                compositeCanvas();
              }}
              className="w-full accent-white h-0.5 rounded-full cursor-pointer bg-neutral-700"
            />
          </div>

          <div className="text-[9px] text-neutral-500 mt-1 border-t border-neutral-800/50 pt-2 italic leading-relaxed">
            Drag sliders to move virtual light and reveal the depth of impasto layers and paper grain.
          </div>
        </div>

        {/* Canvas stage center */}
        <div 
          className="flex-1 flex items-center justify-center p-8 bg-neutral-950/40 relative select-none"
          onContextMenu={(e) => e.preventDefault()}
        >
          {/* Main draw container */}
          <div 
            ref={containerRef}
            className="relative shadow-2xl rounded border border-neutral-800 max-w-full max-h-full aspect-square"
            style={{
              width: `${artwork.width}px`,
              height: `${artwork.height}px`,
              maxWidth: '100%',
              maxHeight: '100%',
            }}
          >
            {/* Background Paper texture render context */}
            <canvas
              ref={paperCanvasRef}
              className="absolute inset-0 pointer-events-none hidden"
            />

            {/* Offline Composite buffer context */}
            <canvas
              ref={compositeCanvasRef}
              className="absolute inset-0 pointer-events-none hidden"
            />

            {/* Render Display Canvas (receives composite buffer) */}
            <canvas
              ref={displayCanvasRef}
              onPointerDown={handlePointerDown}
              onPointerMove={handlePointerMove}
              onPointerUp={handlePointerUp}
              onPointerLeave={handlePointerUp}
              onPointerCancel={handlePointerUp}
              className="absolute inset-0 w-full h-full cursor-crosshair bg-white touch-none shadow-inner"
              style={{ imageRendering: 'pixelated' }}
            />

            {/* Spatial menu portal overlays */}
            <AnimatePresence>
              {radialMenu.isOpen && (
                <RadialMenu
                  x={radialMenu.x}
                  y={radialMenu.y}
                  isOpen={radialMenu.isOpen}
                  brushSettings={brushSettings}
                  setBrushSettings={setBrushSettings}
                  layers={layers}
                  activeLayerId={activeLayerId}
                  setActiveLayerId={setActiveLayerId}
                  onAddLayer={handleAddLayer}
                  onDeleteLayer={handleDeleteLayer}
                  onToggleLayerVisibility={handleToggleLayerVisibility}
                  onLayerOpacityChange={handleLayerOpacityChange}
                  onClose={() => setRadialMenu((prev) => ({ ...prev, isOpen: false }))}
                />
              )}
            </AnimatePresence>
          </div>
        </div>
      </div>

      {/* Footer Spatial Summon Instructions bar */}
      <footer className="h-10 border-t border-neutral-900 bg-neutral-950 px-6 flex items-center justify-between text-neutral-500 font-mono text-[9px] z-10">
        <div className="flex items-center gap-2">
          <span className="bg-neutral-800 text-neutral-300 px-1.5 py-0.5 rounded border border-neutral-700">Spacebar + Click/Pen</span>
          <span>Summons Spatial Controls Menu anywhere on canvas</span>
        </div>

        {/* Alternative Menu Summoner for tablet/pen interfaces without keyboard */}
        <button
          onClick={() => {
            setRadialMenu({
              isOpen: !radialMenu.isOpen,
              x: window.innerWidth / 2,
              y: window.innerHeight / 2,
            });
          }}
          className="bg-neutral-800 hover:bg-neutral-700 text-neutral-200 border border-neutral-700 px-3 py-1 rounded-full font-sans font-bold flex items-center gap-1.5 pointer-events-auto cursor-pointer"
        >
          <span>Radial Controls Overlay</span>
          <ChevronRight size={10} />
        </button>

        <div className="flex items-center gap-2">
          <span>ACTIVE LAYER: <b className="text-neutral-400 uppercase">{layers.find(l => l.id === activeLayerId)?.name}</b></span>
          <span>•</span>
          <button onClick={handleClearCanvas} className="text-red-500/80 hover:text-red-400 font-sans font-semibold underline cursor-pointer">
            Clear Layer
          </button>
        </div>
      </footer>
    </div>
  );
}
