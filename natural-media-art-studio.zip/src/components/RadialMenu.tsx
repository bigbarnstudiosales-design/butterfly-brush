import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Paintbrush, Droplet, Plus, Eye, EyeOff, Layers, Sparkles, 
  Trash2, Sliders, Palette, ChevronRight, X, Star, Search
} from 'lucide-react';
import { BrushSettings, BrushType, Layer, PigmentMix } from '../types';
import { BASE_PIGMENTS, pigmentMixToHex } from '../utils/kubelkaMunk';

interface RadialMenuProps {
  x: number;
  y: number;
  isOpen: boolean;
  brushSettings: BrushSettings;
  setBrushSettings: (settings: BrushSettings) => void;
  layers: Layer[];
  activeLayerId: string;
  setActiveLayerId: (id: string) => void;
  onAddLayer: () => void;
  onDeleteLayer: (id: string) => void;
  onToggleLayerVisibility: (id: string) => void;
  onLayerOpacityChange: (id: string, opacity: number) => void;
  onClose: () => void;
}

type TabType = 'color' | 'brush' | 'layers';

interface BrushPreset {
  id: string;
  name: string;
  type: BrushType;
  size: number;
  opacity: number;
  fluidity: number;
  paintLoad: number;
}

interface LibraryBrush {
  id: string;
  name: string;
  category: 'wet' | 'dry' | 'precision';
  type: BrushType;
  size: number;
  opacity: number;
  fluidity: number;
  paintLoad: number;
  description: string;
}

const BRUSH_LIBRARY: LibraryBrush[] = [
  { id: 'lib-1', name: 'Fluid Wash Watercolor', category: 'wet', type: 'watercolor', size: 90, opacity: 0.45, fluidity: 0.9, paintLoad: 0.6, description: 'Broad, wet washes that bleed gracefully' },
  { id: 'lib-2', name: 'Detail Sable Watercolor', category: 'wet', type: 'watercolor', size: 12, opacity: 0.85, fluidity: 0.7, paintLoad: 0.4, description: 'Fine watercolor detail with sharp points' },
  { id: 'lib-3', name: 'Sponge Dappler', category: 'wet', type: 'watercolor', size: 65, opacity: 0.6, fluidity: 0.8, paintLoad: 0.75, description: 'Textured dabbing with medium absorption' },
  { id: 'lib-4', name: 'Hog Bristle Oil', category: 'wet', type: 'oil', size: 35, opacity: 0.9, fluidity: 0.3, paintLoad: 0.7, description: 'Coarse hair brush leaving rich oil grooves' },
  { id: 'lib-5', name: 'Impasto Palette Knife', category: 'wet', type: 'oil', size: 70, opacity: 1.0, fluidity: 0.15, paintLoad: 0.95, description: 'Thick, unblended paint laid down with metal' },
  { id: 'lib-6', name: 'Glazing Fan Oil', category: 'wet', type: 'oil', size: 50, opacity: 0.35, fluidity: 0.6, paintLoad: 0.5, description: 'Thin, semi-transparent layers of glossy oil' },
  { id: 'lib-7', name: 'Alcohol Felt Marker', category: 'wet', type: 'marker', size: 28, opacity: 0.65, fluidity: 0.5, paintLoad: 0.6, description: 'Broad chisel marker with smooth overlap' },
  { id: 'lib-8', name: 'Fine Point Pen', category: 'precision', type: 'ink', size: 3, opacity: 1.0, fluidity: 0.05, paintLoad: 0.15, description: 'High-contrast precision black technical pen' },
  { id: 'lib-9', name: 'Calligraphy Nib', category: 'precision', type: 'ink', size: 18, opacity: 1.0, fluidity: 0.3, paintLoad: 0.7, description: 'Elegant tapered ink lines for scripting' },
  { id: 'lib-10', name: '2H Hard Pencil', category: 'precision', type: 'graphite', size: 4, opacity: 0.8, fluidity: 0.1, paintLoad: 0.2, description: 'Very light, sharp technical drawing lead' },
  { id: 'lib-11', name: '6B Sketching Lead', category: 'precision', type: 'graphite', size: 14, opacity: 0.9, fluidity: 0.2, paintLoad: 0.4, description: 'Soft graphite lead for dark shading lines' },
  { id: 'lib-12', name: 'Charcoal Shading Block', category: 'dry', type: 'charcoal', size: 85, opacity: 0.65, fluidity: 0.4, paintLoad: 0.55, description: 'Broad flat charcoal stick for dynamic shadows' },
  { id: 'lib-13', name: 'Detail Vine Charcoal', category: 'dry', type: 'charcoal', size: 10, opacity: 0.85, fluidity: 0.2, paintLoad: 0.4, description: 'Thin charcoal twigs for outlining outlines' },
  { id: 'lib-14', name: 'Chalk Pastel Rod', category: 'dry', type: 'pastel', size: 45, opacity: 0.8, fluidity: 0.35, paintLoad: 0.7, description: 'Vibrant powdery pastel stick for rich color' },
  { id: 'lib-15', name: 'Soft Velvet Blender', category: 'dry', type: 'pastel', size: 110, opacity: 0.3, fluidity: 0.6, paintLoad: 0.2, description: 'Smudges and softens existing pastel colors' },
];

export default function RadialMenu({
  x,
  y,
  isOpen,
  brushSettings,
  setBrushSettings,
  layers,
  activeLayerId,
  setActiveLayerId,
  onAddLayer,
  onDeleteLayer,
  onToggleLayerVisibility,
  onLayerOpacityChange,
  onClose,
}: RadialMenuProps) {
  const [activeTab, setActiveTab] = useState<TabType>('brush');
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'wet' | 'dry' | 'precision'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const [activePigmentMix, setActivePigmentMix] = useState<PigmentMix>(
    brushSettings.pigmentMix || {
      cadmiumRed: 0.2,
      ultramarineBlue: 0.2,
      lemonYellow: 0.2,
      titaniumWhite: 0.4,
      lampBlack: 0.0,
    }
  );

  // Favorites state loaded from local storage
  const [favorites, setFavorites] = useState<BrushPreset[]>(() => {
    try {
      const stored = localStorage.getItem('natural_media_studio_fav_brushes_v1');
      if (stored) return JSON.parse(stored);
    } catch (e) {}
    return [
      { id: 'fav-1', name: 'Wet Wash', type: 'watercolor', size: 75, opacity: 0.5, fluidity: 0.8, paintLoad: 0.6 },
      { id: 'fav-2', name: 'Impasto Oil', type: 'oil', size: 45, opacity: 0.95, fluidity: 0.25, paintLoad: 0.9 },
      { id: 'fav-3', name: '6B Pencil', type: 'graphite', size: 12, opacity: 0.85, fluidity: 0.1, paintLoad: 0.3 },
      { id: 'fav-4', name: 'Chalk Pastel', type: 'pastel', size: 55, opacity: 0.75, fluidity: 0.3, paintLoad: 0.6 },
      { id: 'fav-5', name: 'Calligraphy Ink', type: 'ink', size: 18, opacity: 1.0, fluidity: 0.3, paintLoad: 0.7 },
    ];
  });

  const saveFavorites = (updated: BrushPreset[]) => {
    setFavorites(updated);
    try {
      localStorage.setItem('natural_media_studio_fav_brushes_v1', JSON.stringify(updated));
    } catch (e) {}
  };

  // Sync initial pigment mix
  useEffect(() => {
    if (brushSettings.pigmentMix) {
      setActivePigmentMix(brushSettings.pigmentMix);
    }
  }, [brushSettings]);

  const previewCanvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = previewCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // BACKGROUND REMOVED - DRAW DIRECTLY TRANSPARENT AS REQUESTED

    const color = brushSettings.color || '#ffffff';
    const size = brushSettings.size;
    const opacity = brushSettings.opacity;
    const type = brushSettings.type;

    // Map size (1 to 150) to a reasonable preview stroke width (e.g. 2px to 14px)
    const previewWidth = Math.max(2, Math.min(14, (size / 150) * 12 + 2));

    ctx.save();

    if (type === 'watercolor') {
      // Soft translucent bleeding stroke
      const points: { x: number; y: number }[] = [];
      for (let t = 0; t <= 1; t += 0.05) {
        const px = w * 0.25 + (w * 0.5) * t;
        const py = h * 0.7 - (h * 0.4) * t + Math.sin(t * Math.PI) * 3;
        points.push({ x: px, y: py });
      }

      // 1. Broad soft wet wash base
      ctx.globalAlpha = opacity * 0.3;
      ctx.strokeStyle = color;
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';
      ctx.lineWidth = previewWidth * 1.5;
      ctx.beginPath();
      ctx.moveTo(points[0].x, points[0].y);
      for (let i = 1; i < points.length; i++) {
        ctx.lineTo(points[i].x, points[i].y);
      }
      ctx.stroke();

      // 2. Saturated wet-edge blend line
      ctx.globalAlpha = opacity * 0.75;
      ctx.lineWidth = previewWidth * 0.9;
      ctx.stroke();

      // 3. Darker pigment outline/ring
      ctx.globalAlpha = opacity * 0.4;
      ctx.strokeStyle = color;
      ctx.lineWidth = previewWidth * 1.05;
      ctx.stroke();

    } else if (type === 'oil') {
      // Viscous bristle-stroked paint
      const points: { x: number; y: number }[] = [];
      for (let t = 0; t <= 1; t += 0.02) {
        const px = w * 0.25 + (w * 0.5) * t;
        const py = h * 0.7 - (h * 0.4) * t;
        points.push({ x: px, y: py });
      }

      ctx.globalAlpha = opacity;
      ctx.strokeStyle = color;
      ctx.lineWidth = previewWidth;
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(points[0].x, points[0].y);
      for (let i = 1; i < points.length; i++) {
        ctx.lineTo(points[i].x, points[i].y);
      }
      ctx.stroke();

      // Draw lighter highlights and darker shadow streaks to simulate 3D impasto bristles
      const bristleCount = 4;
      for (let b = 0; b < bristleCount; b++) {
        const offset = (b - (bristleCount - 1) / 2) * (previewWidth / bristleCount);
        ctx.lineWidth = Math.max(0.75, previewWidth / bristleCount);
        ctx.beginPath();
        if (b % 2 === 0) {
          ctx.strokeStyle = 'rgba(255, 255, 255, 0.35)'; // Highlight
        } else {
          ctx.strokeStyle = 'rgba(0, 0, 0, 0.15)'; // Shadow
        }
        ctx.moveTo(points[0].x + offset, points[0].y + offset);
        for (let i = 1; i < points.length; i++) {
          ctx.lineTo(points[i].x + offset, points[i].y + offset);
        }
        ctx.stroke();
      }

    } else if (type === 'charcoal' || type === 'pastel') {
      // Granular, powdery organic medium
      const points: { x: number; y: number }[] = [];
      for (let t = 0; t <= 1; t += 0.02) {
        const px = w * 0.25 + (w * 0.5) * t;
        const py = h * 0.7 - (h * 0.4) * t;
        points.push({ x: px, y: py });
      }

      ctx.globalAlpha = opacity;
      ctx.fillStyle = color;

      points.forEach((pt) => {
        const density = type === 'charcoal' ? 10 : 16;
        const spread = previewWidth * 0.6;
        for (let p = 0; p < density; p++) {
          const angle = Math.random() * Math.PI * 2;
          const radius = Math.random() * spread;
          const px = pt.x + Math.cos(angle) * radius;
          const py = pt.y + Math.sin(angle) * radius;
          const pSize = Math.random() * 1.2 + 0.4;
          
          ctx.beginPath();
          ctx.arc(px, py, pSize, 0, Math.PI * 2);
          ctx.fill();
        }
      });

    } else if (type === 'graphite') {
      // Crisp pencil line with micro texture
      const points: { x: number; y: number }[] = [];
      for (let t = 0; t <= 1; t += 0.02) {
        const px = w * 0.25 + (w * 0.5) * t;
        const py = h * 0.7 - (h * 0.4) * t + (Math.random() - 0.5) * 0.5;
        points.push({ x: px, y: py });
      }

      ctx.globalAlpha = opacity * 0.9;
      ctx.strokeStyle = color;
      ctx.lineWidth = Math.max(1, previewWidth * 0.2);
      ctx.lineCap = 'round';
      ctx.beginPath();
      ctx.moveTo(points[0].x, points[0].y);
      for (let i = 1; i < points.length; i++) {
        ctx.lineTo(points[i].x, points[i].y);
      }
      ctx.stroke();

      // Draw secondary shading line
      ctx.beginPath();
      ctx.moveTo(points[0].x - 0.8, points[0].y + 0.8);
      for (let i = 1; i < points.length; i++) {
        ctx.lineTo(points[i].x - 0.8, points[i].y + 0.8);
      }
      ctx.stroke();

    } else if (type === 'ink') {
      // Tapered, high-contrast, smooth stroke
      const points: { x: number; y: number }[] = [];
      for (let t = 0; t <= 1; t += 0.01) {
        const px = w * 0.25 + (w * 0.5) * t;
        const py = h * 0.7 - (h * 0.4) * t;
        points.push({ x: px, y: py });
      }

      ctx.globalAlpha = opacity;
      ctx.fillStyle = color;

      for (let i = 0; i < points.length; i++) {
        const t = i / (points.length - 1);
        const scaleFactor = Math.sin(t * Math.PI); // tapered at ends
        const currentSize = previewWidth * (0.35 + scaleFactor * 0.65) * 0.45;

        ctx.beginPath();
        ctx.arc(points[i].x, points[i].y, currentSize, 0, Math.PI * 2);
        ctx.fill();
      }

    } else if (type === 'marker') {
      // Translucent layered marker stroke (chisel)
      const points: { x: number; y: number }[] = [];
      for (let t = 0; t <= 1; t += 0.08) {
        const px = w * 0.25 + (w * 0.5) * t;
        const py = h * 0.7 - (h * 0.4) * t;
        points.push({ x: px, y: py });
      }

      ctx.globalAlpha = opacity * 0.55;
      ctx.fillStyle = color;

      points.forEach((pt) => {
        ctx.save();
        ctx.translate(pt.x, pt.y);
        ctx.rotate(-Math.PI / 6);
        ctx.fillRect(-previewWidth * 0.4, -previewWidth * 0.7, previewWidth * 0.8, previewWidth * 1.4);
        ctx.restore();
      });
    }

    ctx.restore();
  }, [brushSettings]);

  const handlePigmentChange = (pigment: keyof PigmentMix, value: number) => {
    const updatedMix = { ...activePigmentMix, [pigment]: parseFloat(value.toFixed(2)) };
    setActivePigmentMix(updatedMix);
    const hexColor = pigmentMixToHex(updatedMix);
    setBrushSettings({
      ...brushSettings,
      color: hexColor,
      pigmentMix: updatedMix,
    });
  };

  const updateSetting = (key: keyof BrushSettings, value: number | string) => {
    setBrushSettings({
      ...brushSettings,
      [key]: value,
    });
  };

  const filteredBrushes = BRUSH_LIBRARY.filter((brush) => {
    const matchesCat = selectedCategory === 'all' || brush.category === selectedCategory;
    const matchesSearch = brush.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          brush.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          brush.type.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCat && matchesSearch;
  });

  if (!isOpen) return null;

  // Render coordinates within bounds of viewport
  const menuWidth = 420;
  const menuHeight = 420;
  const adjustedX = Math.max(20, Math.min(window.innerWidth - menuWidth - 20, x - menuWidth / 2));
  const adjustedY = Math.max(20, Math.min(window.innerHeight - menuHeight - 20, y - menuHeight / 2));

  return (
    <div 
      id="radial-menu-overlay"
      className="absolute z-50 pointer-events-auto"
      style={{ left: adjustedX, top: adjustedY }}
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.85 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.85 }}
        transition={{ type: 'spring', damping: 20, stiffness: 300 }}
        className="relative w-[420px] h-[420px] bg-neutral-900/95 backdrop-blur-md rounded-full border border-neutral-700 shadow-2xl p-6 flex flex-col justify-between items-center text-white select-none"
      >
        {/* Radial Header / Mode Selection */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 flex items-center gap-1 bg-neutral-800 rounded-full p-1 border border-neutral-700/50">
          <button
            onClick={() => setActiveTab('brush')}
            className={`px-3 py-1 text-xs font-semibold rounded-full transition-all ${
              activeTab === 'brush' ? 'bg-neutral-100 text-neutral-900' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Media
          </button>
          <button
            onClick={() => setActiveTab('color')}
            className={`px-3 py-1 text-xs font-semibold rounded-full transition-all ${
              activeTab === 'color' ? 'bg-neutral-100 text-neutral-900' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Pigments
          </button>
          <button
            onClick={() => setActiveTab('layers')}
            className={`px-3 py-1 text-xs font-semibold rounded-full transition-all ${
              activeTab === 'layers' ? 'bg-neutral-100 text-neutral-900' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Layers
          </button>
        </div>

        {/* Five Favorite Brushes for Quick Access */}
        <div className="absolute top-14 left-1/2 -translate-x-1/2 flex items-center gap-2 bg-neutral-950/50 px-3 py-1 rounded-full border border-neutral-800/60 shadow-lg backdrop-blur-sm z-20">
          {favorites.map((fav, idx) => {
            const isCurrentlySelected = brushSettings.type === fav.type &&
                                        brushSettings.size === fav.size &&
                                        brushSettings.opacity === fav.opacity &&
                                        brushSettings.fluidity === fav.fluidity &&
                                        brushSettings.paintLoad === fav.paintLoad;
            
            const Icon = fav.type === 'watercolor' || fav.type === 'marker' ? Droplet :
                         fav.type === 'oil' || fav.type === 'ink' ? Paintbrush :
                         fav.type === 'charcoal' || fav.type === 'pastel' ? Sparkles : Sliders;

            return (
              <div key={fav.id} className="relative group">
                <button
                  onClick={() => {
                    setBrushSettings({
                      ...brushSettings,
                      type: fav.type,
                      size: fav.size,
                      opacity: fav.opacity,
                      fluidity: fav.fluidity,
                      paintLoad: fav.paintLoad,
                    });
                  }}
                  className={`w-7 h-7 rounded-full flex items-center justify-center border text-[11px] transition-all relative ${
                    isCurrentlySelected
                      ? 'bg-white border-white text-neutral-950 shadow-md font-bold scale-110'
                      : 'bg-neutral-800/80 border-neutral-700/60 text-neutral-300 hover:border-neutral-500 hover:bg-neutral-700'
                  }`}
                  title={`${fav.name} (${fav.size}px)`}
                >
                  <Icon size={11} className={isCurrentlySelected ? 'text-neutral-950' : 'text-neutral-300'} />
                  <span className="absolute -bottom-1 -right-1 bg-neutral-950/90 text-white border border-neutral-800 rounded-full w-3.5 h-3.5 flex items-center justify-center text-[7px] font-mono font-bold scale-90">
                    {idx + 1}
                  </span>
                </button>

                {/* Star Overlay to quickly save current settings on hover */}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    const updated = [...favorites];
                    updated[idx] = {
                      ...favorites[idx],
                      type: brushSettings.type,
                      size: brushSettings.size,
                      opacity: brushSettings.opacity,
                      fluidity: brushSettings.fluidity,
                      paintLoad: brushSettings.paintLoad,
                      name: `Favorite ${idx + 1} (${brushSettings.type})`,
                    };
                    saveFavorites(updated);
                  }}
                  className="absolute -top-1.5 -right-1 bg-amber-500 hover:bg-amber-400 text-neutral-950 rounded-full w-4 h-4 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md z-30"
                  title="Save current brush to this slot"
                >
                  <Star size={7} fill="currentColor" />
                </button>
              </div>
            );
          })}
        </div>

        {/* Central Core (Displays Live Brush Preview - Transparent background) */}
        <div 
          className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-16 h-16 rounded-full flex items-center justify-center border border-neutral-700/60 overflow-hidden z-10 transition-all duration-300"
          style={{ 
            borderColor: pigmentMixToHex(activePigmentMix),
            boxShadow: `0 0 16px ${pigmentMixToHex(activePigmentMix)}aa`
          }}
          title={`${brushSettings.type} (${brushSettings.size}px, opacity: ${Math.round(brushSettings.opacity * 100)}%)`}
        >
          <canvas 
            ref={previewCanvasRef} 
            width={64} 
            height={64} 
            className="w-full h-full object-cover"
          />
        </div>

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute bottom-4 right-4 bg-neutral-800 p-2 rounded-full border border-neutral-700 hover:bg-neutral-700 text-neutral-300 hover:text-white transition-all shadow-md"
          title="Close Menu (or release Space)"
        >
          <X size={14} />
        </button>

        {/* Dynamic Content Panel based on selected Tab */}
        <div className="w-full h-full flex items-center justify-center p-8 mt-12 overflow-hidden">
          <AnimatePresence mode="wait">
            {activeTab === 'brush' && (
              <motion.div
                key="brush"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="w-full h-full flex flex-col justify-between pt-4"
              >
                {/* Search Bar */}
                <div className="relative flex items-center bg-neutral-950/50 rounded-lg px-2 py-1 border border-neutral-800 focus-within:border-neutral-700 transition-all text-xs w-full mb-1">
                  <Search size={11} className="text-neutral-500 mr-1.5" />
                  <input
                    type="text"
                    placeholder="Search hundreds of brushes..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="bg-transparent border-none outline-none text-neutral-200 placeholder-neutral-500 w-full text-[9px]"
                  />
                  {searchQuery && (
                    <button onClick={() => setSearchQuery('')} className="text-neutral-500 hover:text-neutral-300">
                      <X size={9} />
                    </button>
                  )}
                </div>

                {/* Category selectors */}
                <div className="flex gap-1 justify-center mb-1 overflow-x-auto no-scrollbar max-w-full">
                  {(['all', 'wet', 'dry', 'precision'] as const).map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setSelectedCategory(cat)}
                      className={`px-2 py-0.5 rounded text-[7px] uppercase tracking-wider font-bold border transition-all ${
                        selectedCategory === cat
                          ? 'bg-neutral-100 border-white text-neutral-900'
                          : 'bg-neutral-800/40 border-neutral-800 text-neutral-400 hover:text-white'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>

                {/* Scrollable list of structured brushes */}
                <div className="flex-1 overflow-y-auto space-y-1 pr-1 max-h-[105px] no-scrollbar">
                  {filteredBrushes.map((brush) => {
                    const isSelected = brushSettings.type === brush.type && 
                                       brushSettings.size === brush.size && 
                                       brushSettings.opacity === brush.opacity &&
                                       brushSettings.fluidity === brush.fluidity &&
                                       brushSettings.paintLoad === brush.paintLoad;

                    const Icon = brush.type === 'watercolor' || brush.type === 'marker' ? Droplet :
                                 brush.type === 'oil' || brush.type === 'ink' ? Paintbrush :
                                 brush.type === 'charcoal' || brush.type === 'pastel' ? Sparkles : Sliders;

                    return (
                      <button
                        key={brush.id}
                        onClick={() => {
                          setBrushSettings({
                            ...brushSettings,
                            type: brush.type,
                            size: brush.size,
                            opacity: brush.opacity,
                            fluidity: brush.fluidity,
                            paintLoad: brush.paintLoad,
                          });
                        }}
                        className={`w-full flex items-center justify-between p-1 rounded-lg border text-[10px] text-left transition-all ${
                          isSelected 
                            ? 'bg-white/10 border-white/50 text-white font-semibold' 
                            : 'bg-neutral-800/30 border-neutral-800/40 text-neutral-300 hover:bg-neutral-800/60 hover:border-neutral-700'
                        }`}
                      >
                        <div className="flex items-center gap-1.5 min-w-0">
                          <span className={`p-1 rounded ${isSelected ? 'bg-white/10 text-white' : 'bg-neutral-900/60 text-neutral-400'}`}>
                            <Icon size={10} />
                          </span>
                          <div className="truncate">
                            <div className="font-semibold truncate text-[9px]">{brush.name}</div>
                            <div className="text-[7.5px] text-neutral-500 truncate leading-none mt-0.5">{brush.description}</div>
                          </div>
                        </div>
                        <div className="text-[8px] font-mono text-neutral-400 pl-1">
                          {brush.size}px
                        </div>
                      </button>
                    );
                  })}
                </div>

                {/* Compact parameters adjustments */}
                <div className="grid grid-cols-2 gap-x-2 gap-y-1.5 mt-2 bg-neutral-800/30 p-2 rounded-lg border border-neutral-700/20 text-[9px]">
                  <div className="flex flex-col">
                    <span className="text-neutral-400 flex justify-between font-mono text-[8px]">
                      <span>SIZE</span> 
                      <span>{brushSettings.size}px</span>
                    </span>
                    <input
                      type="range"
                      min="1"
                      max="150"
                      value={brushSettings.size}
                      onChange={(e) => updateSetting('size', parseInt(e.target.value))}
                      className="w-full accent-white h-0.5 rounded-full cursor-pointer bg-neutral-700"
                    />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-neutral-400 flex justify-between font-mono text-[8px]">
                      <span>OPACITY</span> 
                      <span>{Math.round(brushSettings.opacity * 100)}%</span>
                    </span>
                    <input
                      type="range"
                      min="0.05"
                      max="1"
                      step="0.01"
                      value={brushSettings.opacity}
                      onChange={(e) => updateSetting('opacity', parseFloat(e.target.value))}
                      className="w-full accent-white h-0.5 rounded-full cursor-pointer bg-neutral-700"
                    />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-neutral-400 flex justify-between font-mono text-[8px]">
                      <span>FLUIDITY</span> 
                      <span>{Math.round(brushSettings.fluidity * 100)}%</span>
                    </span>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.01"
                      value={brushSettings.fluidity}
                      onChange={(e) => updateSetting('fluidity', parseFloat(e.target.value))}
                      className="w-full accent-white h-0.5 rounded-full cursor-pointer bg-neutral-700"
                    />
                  </div>
                  <div className="flex flex-col">
                    <span className="text-neutral-400 flex justify-between font-mono text-[8px]">
                      <span>PAINT LOAD</span> 
                      <span>{Math.round(brushSettings.paintLoad * 100)}%</span>
                    </span>
                    <input
                      type="range"
                      min="0.1"
                      max="1"
                      step="0.01"
                      value={brushSettings.paintLoad}
                      onChange={(e) => updateSetting('paintLoad', parseFloat(e.target.value))}
                      className="w-full accent-white h-0.5 rounded-full cursor-pointer bg-neutral-700"
                    />
                  </div>
                </div>
              </motion.div>
            )}

            {activeTab === 'color' && (
              <motion.div
                key="color"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="w-full h-full flex flex-col justify-between pt-4"
              >
                <div className="text-center text-[10px] font-bold text-neutral-400 mb-2 uppercase tracking-wide">
                  Kubelka-Munk Pigment Mix Ratio
                </div>

                {/* 5 Pigments sliders */}
                <div className="space-y-1.5 flex-1 overflow-y-auto pr-1 no-scrollbar max-h-[170px]">
                  {Object.entries(BASE_PIGMENTS).map(([key, pigment]) => {
                    const mixKey = key as keyof PigmentMix;
                    const value = activePigmentMix[mixKey] || 0;
                    return (
                      <div key={key} className="flex items-center justify-between gap-2.5 text-[10px]">
                        <span className="w-24 text-left font-semibold truncate text-neutral-300" title={pigment.description}>
                          {pigment.name}
                        </span>
                        <input
                          type="range"
                          min="0"
                          max="1"
                          step="0.05"
                          value={value}
                          onChange={(e) => handlePigmentChange(mixKey, parseFloat(e.target.value))}
                          className="flex-1 accent-neutral-200 h-1 rounded-full bg-neutral-800"
                        />
                        <span className="w-8 text-right font-mono text-neutral-400">
                          {Math.round(value * 100)}%
                        </span>
                      </div>
                    );
                  })}
                </div>

                <div className="flex justify-center gap-1.5 mt-2 bg-neutral-800/30 p-1.5 rounded-lg border border-neutral-700/20">
                  {/* Quick color preset dots */}
                  {[
                    { name: 'Pure Red', mix: { cadmiumRed: 1, ultramarineBlue: 0, lemonYellow: 0, titaniumWhite: 0, lampBlack: 0 } },
                    { name: 'Pure Blue', mix: { cadmiumRed: 0, ultramarineBlue: 1, lemonYellow: 0, titaniumWhite: 0, lampBlack: 0 } },
                    { name: 'Pure Yellow', mix: { cadmiumRed: 0, ultramarineBlue: 0, lemonYellow: 1, titaniumWhite: 0, lampBlack: 0 } },
                    { name: 'Ochre Mix', mix: { cadmiumRed: 0.1, ultramarineBlue: 0.05, lemonYellow: 0.6, titaniumWhite: 0.1, lampBlack: 0.15 } },
                    { name: 'Violet Mix', mix: { cadmiumRed: 0.45, ultramarineBlue: 0.45, lemonYellow: 0, titaniumWhite: 0.1, lampBlack: 0 } },
                    { name: 'Teal Mix', mix: { cadmiumRed: 0, ultramarineBlue: 0.4, lemonYellow: 0.3, titaniumWhite: 0.3, lampBlack: 0 } },
                  ].map((p, idx) => (
                    <button
                      key={idx}
                      title={p.name}
                      onClick={() => {
                        setActivePigmentMix(p.mix);
                        setBrushSettings({ ...brushSettings, color: pigmentMixToHex(p.mix), pigmentMix: p.mix });
                      }}
                      className="w-5 h-5 rounded-full border border-neutral-600 cursor-pointer hover:scale-110 transition-all"
                      style={{ backgroundColor: pigmentMixToHex(p.mix) }}
                    />
                  ))}
                </div>
              </motion.div>
            )}

            {activeTab === 'layers' && (
              <motion.div
                key="layers"
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.95 }}
                className="w-full h-full flex flex-col justify-between pt-4"
              >
                <div className="flex justify-between items-center mb-1">
                  <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wide">
                    Canvas Layer Manager
                  </span>
                  <button
                    onClick={onAddLayer}
                    className="flex items-center gap-1 bg-white hover:bg-neutral-200 text-neutral-900 px-2 py-0.5 rounded-full text-[9px] font-bold transition-all"
                  >
                    <Plus size={10} /> Add Layer
                  </button>
                </div>

                {/* Layer stack listing */}
                <div className="flex-1 overflow-y-auto space-y-1 pr-1 max-h-[145px] no-scrollbar">
                  {layers.map((layer) => {
                    const isActive = layer.id === activeLayerId;
                    return (
                      <div
                        key={layer.id}
                        className={`flex items-center justify-between p-2 rounded-lg border text-[10px] transition-all ${
                          isActive 
                            ? 'bg-white/10 border-white/50 text-white font-semibold' 
                            : 'bg-neutral-800/40 border-neutral-700/40 text-neutral-300 hover:bg-neutral-800/80'
                        }`}
                      >
                        <div 
                          className="flex items-center gap-1.5 cursor-pointer flex-1 truncate"
                          onClick={() => setActiveLayerId(layer.id)}
                        >
                          <Layers size={11} className={isActive ? 'text-white' : 'text-neutral-500'} />
                          <span className="truncate">{layer.name}</span>
                        </div>

                        <div className="flex items-center gap-1.5 pl-2">
                          {/* Visibility toggle */}
                          <button
                            onClick={() => onToggleLayerVisibility(layer.id)}
                            className="text-neutral-400 hover:text-white transition-colors"
                          >
                            {layer.visible ? <Eye size={12} /> : <EyeOff size={12} />}
                          </button>

                          {/* Delete Layer button (prevent if last remaining layer) */}
                          {layers.length > 1 && (
                            <button
                              onClick={() => onDeleteLayer(layer.id)}
                              className="text-neutral-400 hover:text-red-400 transition-colors"
                            >
                              <Trash2 size={12} />
                            </button>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>

                {/* Active Layer Opacity slide */}
                {layers.find(l => l.id === activeLayerId) && (
                  <div className="mt-2 bg-neutral-800/50 p-2 rounded-lg border border-neutral-700/30 text-[9px]">
                    <div className="flex justify-between text-neutral-400 font-mono mb-1">
                      <span>ACTIVE LAYER OPACITY</span>
                      <span>
                        {Math.round((layers.find(l => l.id === activeLayerId)?.opacity || 0) * 100)}%
                      </span>
                    </div>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={layers.find(l => l.id === activeLayerId)?.opacity || 0}
                      onChange={(e) => onLayerOpacityChange(activeLayerId, parseFloat(e.target.value))}
                      className="w-full accent-white h-1 rounded-full cursor-pointer bg-neutral-700"
                    />
                  </div>
                )}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Dynamic Spatial menu arcs indicator */}
        <div className="absolute inset-0 rounded-full border border-dashed border-neutral-600/25 pointer-events-none scale-105" />
        <div className="absolute inset-0 rounded-full border border-dashed border-neutral-500/10 pointer-events-none scale-110" />
      </motion.div>
    </div>
  );
}
